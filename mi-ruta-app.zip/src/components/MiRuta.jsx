import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, CalendarCheck, HeartHandshake, Users } from "lucide-react";

export default function MiRuta() {
  return (
    <div className="p-6 max-w-5xl mx-auto space-y-8">
      <header className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-purple-700">Mi Ruta</h1>
        <p className="text-lg text-gray-600">
          Acompañamiento Integral para el Bienestar y Éxito Estudiantil
        </p>
        <Button className="bg-purple-700 hover:bg-purple-800 text-white">Explora tu camino</Button>
      </header>

      <section className="grid md:grid-cols-2 gap-6">
        <Card className="shadow-md">
          <CardContent className="p-6 space-y-3">
            <div className="flex items-center space-x-3">
              <CalendarCheck className="text-purple-600" />
              <h2 className="text-xl font-semibold">Seguimiento de metas</h2>
            </div>
            <p className="text-gray-600">
              Planifica tus tareas, evalúa tus logros y mantente motivado con metas semanales.
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardContent className="p-6 space-y-3">
            <div className="flex items-center space-x-3">
              <HeartHandshake className="text-purple-600" />
              <h2 className="text-xl font-semibold">Apoyo emocional</h2>
            </div>
            <p className="text-gray-600">
              Accede a frases motivadoras, diarios emocionales y espacios de escucha.
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardContent className="p-6 space-y-3">
            <div className="flex items-center space-x-3">
              <Sparkles className="text-purple-600" />
              <h2 className="text-xl font-semibold">Hábitos y organización</h2>
            </div>
            <p className="text-gray-600">
              Aprende técnicas de estudio y usa agendas personalizadas para tu día a día.
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardContent className="p-6 space-y-3">
            <div className="flex items-center space-x-3">
              <Users className="text-purple-600" />
              <h2 className="text-xl font-semibold">Comunidad estudiantil</h2>
            </div>
            <p className="text-gray-600">
              Conéctate con otros estudiantes, comparte estrategias y apóyate en grupo.
            </p>
          </CardContent>
        </Card>
      </section>

      <footer className="text-center text-gray-400 text-sm pt-10">
        © 2025 Mi Ruta – Proyecto Educativo para el Bienestar Estudiantil
      </footer>
    </div>
  );
}