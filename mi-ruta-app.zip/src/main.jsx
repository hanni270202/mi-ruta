import React from 'react'
import ReactDOM from 'react-dom/client'
import MiRuta from './components/MiRuta'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <MiRuta />
  </React.StrictMode>,
)